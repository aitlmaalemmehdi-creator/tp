import { useState } from "react";
import { useLocalStorage } from "./hooks.js";
import TaskForm from "./components/TaskForm.jsx";
import TaskItem from "./components/TaskItem.jsx";

const FILTERS = ["toutes", "à faire", "terminées"];

export default function App() {
  const [tasks, setTasks] = useLocalStorage("taches-v1", []);
  const [filter, setFilter] = useState("toutes");

  const addTask = (title, priority) =>
    setTasks([{ id: Date.now(), title, priority, done: false }, ...tasks]);

  const toggleTask = (id) =>
    setTasks(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));

  const renameTask = (id, title) =>
    setTasks(tasks.map((t) => (t.id === id ? { ...t, title } : t)));

  const deleteTask = (id) => setTasks(tasks.filter((t) => t.id !== id));

  const clearDone = () => setTasks(tasks.filter((t) => !t.done));

  const doneCount = tasks.filter((t) => t.done).length;
  const percent = tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0;

  const shown = tasks.filter((t) =>
    filter === "toutes" ? true : filter === "à faire" ? !t.done : t.done
  );

  return (
    <main>
      <h1>Mes tâches</h1>
      <p className="sub">
        {tasks.length
          ? `${doneCount} terminée(s) sur ${tasks.length}`
          : "Ajoutez votre première tâche pour commencer."}
      </p>

      <div className="bar" role="progressbar" aria-valuenow={percent} aria-valuemin="0" aria-valuemax="100">
        <i style={{ width: `${percent}%` }} />
      </div>

      <TaskForm onAdd={addTask} />

      <div className="tabs">
        {FILTERS.map((f) => (
          <button key={f} className="tab" aria-pressed={filter === f} onClick={() => setFilter(f)}>
            {f[0].toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {shown.length ? (
        <ul>
          {shown.map((t) => (
            <TaskItem key={t.id} task={t} onToggle={toggleTask} onRename={renameTask} onDelete={deleteTask} />
          ))}
        </ul>
      ) : (
        <div className="empty">
          {tasks.length ? "Aucune tâche dans cette vue." : "Rien à faire pour l’instant. Ajoutez une tâche ci-dessus."}
        </div>
      )}

      <div className="foot">
        <span>{tasks.length - doneCount} à faire</span>
        {doneCount > 0 && (
          <button className="link" onClick={clearDone}>
            Supprimer les terminées
          </button>
        )}
      </div>
    </main>
  );
}
