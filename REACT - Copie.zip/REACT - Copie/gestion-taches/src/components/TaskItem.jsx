import { useState } from "react";

export default function TaskItem({ task, onToggle, onRename, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(task.title);

  const save = () => {
    const v = value.trim();
    if (v) onRename(task.id, v);
    else setValue(task.title);
    setEditing(false);
  };

  const onKeyDown = (e) => {
    if (e.key === "Enter") save();
    if (e.key === "Escape") {
      setValue(task.title);
      setEditing(false);
    }
  };

  return (
    <li className={`p-${task.priority}${task.done ? " done" : ""}`}>
      <input
        type="checkbox"
        checked={task.done}
        onChange={() => onToggle(task.id)}
        aria-label={`Terminer : ${task.title}`}
      />

      {editing ? (
        <input
          className="edit"
          type="text"
          autoFocus
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={save}
          onKeyDown={onKeyDown}
        />
      ) : (
        <span className="txt" title="Double-clic pour modifier" onDoubleClick={() => setEditing(true)}>
          {task.title}
        </span>
      )}

      <span className="tag">{task.priority}</span>
      <button className="icon" onClick={() => setEditing(true)}>Modifier</button>
      <button className="icon" onClick={() => onDelete(task.id)}>Supprimer</button>
    </li>
  );
}
