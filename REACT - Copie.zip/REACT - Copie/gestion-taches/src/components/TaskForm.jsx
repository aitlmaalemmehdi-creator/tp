import { useState } from "react";

export default function TaskForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("moyenne");

  const handleSubmit = (e) => {
    e.preventDefault();
    const value = title.trim();
    if (!value) return;
    onAdd(value, priority);
    setTitle("");
  };

  return (
    <form className="add" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Que devez-vous faire ?"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        aria-label="Nouvelle tâche"
      />
      <select value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Priorité">
        <option value="haute">Haute</option>
        <option value="moyenne">Moyenne</option>
        <option value="basse">Basse</option>
      </select>
      <button className="primary" type="submit">
        Ajouter
      </button>
    </form>
  );
}
